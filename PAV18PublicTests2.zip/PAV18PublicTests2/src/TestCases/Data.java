package TestCases;

public class Data {
	int data;
	
	public Data(int i) {
		data = i;
	}
	
	public Data() {
		data = 0;
	}
}
