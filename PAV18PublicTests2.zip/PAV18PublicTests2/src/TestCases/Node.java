package TestCases;

public class Node {
	Node next;
	Node prev;
	Data data;
}