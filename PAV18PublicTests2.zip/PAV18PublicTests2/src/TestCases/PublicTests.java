package TestCases;

public class PublicTests {
	
	public static void main(String[] args) {
		Test1 t1 = new Test1();
		t1.foo();
		Test2 t2 = new Test2();
		t2.array();
	}
}